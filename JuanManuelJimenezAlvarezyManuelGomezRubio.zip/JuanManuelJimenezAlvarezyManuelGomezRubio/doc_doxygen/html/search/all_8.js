var searchData=
[
  ['representación_20del_20tda_20imagen_17',['Representación del TDA Imagen',['../page_repImagen.html',1,'']]],
  ['readimagekind_18',['ReadImageKind',['../imageIO_8h.html#aae1362cc5bced97d9e2c15aaa8ce313d',1,'ReadImageKind(const char *path):&#160;imageIO.cpp'],['../imageIO_8cpp.html#a6dea11974ea8c8c101628f3505960a39',1,'ReadImageKind(const char *nombre):&#160;imageIO.cpp']]],
  ['readpgmimage_19',['ReadPGMImage',['../imageIO_8h.html#a6c7d905cd8ffaf23decf9d279f362a97',1,'ReadPGMImage(const char *path, int &amp;rows, int &amp;cols):&#160;imageIO.cpp'],['../imageIO_8cpp.html#a6c7d905cd8ffaf23decf9d279f362a97',1,'ReadPGMImage(const char *path, int &amp;rows, int &amp;cols):&#160;imageIO.cpp']]]
];
