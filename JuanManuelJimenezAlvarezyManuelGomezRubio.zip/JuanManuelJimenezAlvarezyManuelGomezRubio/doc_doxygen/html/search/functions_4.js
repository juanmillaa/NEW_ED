var searchData=
[
  ['image_40',['Image',['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#a24d6fed0a7c3dc53b86411dd68bfbb2e',1,'Image::Image(int nrows, int ncols, byte value=0)'],['../classImage.html#abda271aa11b907dda8c8c8176684227d',1,'Image::Image(const Image &amp;orig)']]],
  ['invert_41',['Invert',['../classImage.html#a6c9c1b3fef7795378f8a56fdd491ffa0',1,'Image']]]
];
